import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.voidrevelation.game',
  appName: 'VOID REVELATION',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
