# VOID REVELATION — Build and publish on Android

## 1. Play the game on a computer first
Open `www/index.html` in a modern browser. For mobile testing, the game is designed for touch input and portrait orientation.

## 2. Install tools
Install Node.js 22 or newer and Android Studio. In Android Studio's SDK Manager, install Android SDK Platform 36 and the Android SDK build tools. Capacitor 8 requires a recent Android Studio version; check the current Capacitor environment setup guide.

## 3. Generate the Android project
Extract this ZIP, open a terminal in the extracted `void_revelation_android` folder, then run:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

If `android/` already exists, skip `npx cap add android`; use `npx cap sync android` after changing the game.

## 4. Test on a phone
In Android Studio, enable Developer options and USB debugging on your Android phone, connect it, select the device, and press Run. Test touch controls, pause/restart, screen sizes, background/resume, and gameplay. This starter uses local game assets and does not require an account or server to play.

## 5. Prepare a release build
In Android Studio, choose **Build → Generate Signed Bundle / APK → Android App Bundle**. Create and securely back up an upload key when prompted. Build a signed `.aab` release. Do not share your keystore or passwords. Keep the same application ID (`com.voidrevelation.game`) for future updates.

## 6. Google Play requirements
- Google Play Console registration requires the account holder to be at least 18 years old and costs US$25 once, according to Google's current help page.
- If you're under 18, don't enter a false age or use someone else's identity without permission. Ask a parent/guardian or another trusted adult who is willing to be the genuine account owner/publisher to handle registration, identity checks, agreements, and release; you can help create the game.
- New personal developer accounts may need identity/device verification and must complete Google's required closed testing before production access. Check the requirements shown in that account's Play Console.
- As of 31 August 2026, new apps and updates submitted to Google Play must target Android 16 / API 36 or higher. Verify this in Android Studio/Play Console before upload; Android Gradle plugin settings may need updating.
- Create a store listing: title, short/full descriptions, icon, screenshots, category, contact email, privacy policy if required, content rating questionnaire, target audience, ads declaration, data safety form, and app access instructions if applicable. Answer each honestly.
- Upload the `.aab` to an internal testing track first. Fix crashes and policy issues before requesting production access and publishing.

## 7. Important scope note
This package is a working game prototype and Android wrapper starter, not a finished commercial release. Before publishing, test the built Android app on real devices, add a proper launcher icon and store screenshots, check accessibility/performance, and complete Play's policy forms. No ads, analytics, online accounts, or payments are implemented in this starter.

## Official references
- Play Console registration and age: https://support.google.com/googleplay/android-developer/answer/6112435
- Target API requirements: https://support.google.com/googleplay/android-developer/answer/11926878
- Capacitor setup: https://capacitorjs.com/docs/getting-started/environment-setup
- Capacitor install/sync: https://capacitorjs.com/docs/getting-started
- Android signing/release: https://developer.android.com/studio/publish
