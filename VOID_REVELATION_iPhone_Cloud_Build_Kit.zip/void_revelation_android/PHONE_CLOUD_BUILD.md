# Build VOID REVELATION using only an iPhone

This project includes a GitHub Actions workflow at `.github/workflows/android-cloud-build.yml`.
It can build a debug APK and an **unsigned** release AAB on GitHub-hosted runners.

## What you need
- A GitHub account you are allowed to use.
- Safari or another mobile browser.
- For Google Play publishing, an adult (18+) parent/guardian or other trusted adult who agrees to own and manage the Play Console developer account. Do not enter a false date of birth.

## Steps on iPhone
1. Download and extract the project ZIP in the Files app if possible.
2. Open https://github.com in Safari and sign in or create an account, following the site's current age and account rules. If the account requires an adult's consent or supervision, involve a parent/guardian.
3. Create a **new private repository** named `void-revelation`.
4. Upload the contents of the `void_revelation_android` folder into the repository root. Make sure `package.json`, `capacitor.config.ts`, `www/`, and `.github/workflows/android-cloud-build.yml` are at the repository root (not hidden inside another `void_revelation_android` folder).
5. Open the repository's **Actions** tab. If prompted, enable Actions for the repository.
6. Choose **VOID REVELATION Android cloud build**, then **Run workflow**. If the workflow is not visible, open the `.github/workflows/android-cloud-build.yml` file and confirm it was uploaded at the correct path.
7. Wait for the run to finish. Open the completed run and download the artifact named `void-revelation-android-build`.
8. The artifact contains `app-debug.apk` for testing and `app-release.aab` for the Play Console upload process.

## Important limitations
- The generated `app-release.aab` is **unsigned**. Google Play will not accept it as a final release until it is signed with a secure upload key or configured with a secure signing workflow. Never share a keystore or its passwords publicly or commit them to the repository.
- New Google Play apps generally need an Android App Bundle and must meet the target API level currently required by Google Play. Verify current requirements in Play Console before submission.
- The first build may fail if Android/Capacitor dependency versions or runner toolchains change. If it fails, open the Actions run and share the error text (hide any private information); it can be debugged from there.
- GitHub-hosted build minutes/availability and repository features depend on the account and current GitHub policies.
- This workflow builds the project; it does not create a Play Console account, sign the release, complete store listing/content declarations, or publish the app automatically.
