# VOID REVELATION — Android starter project

This package contains the playable HTML5 game and the configuration to wrap it as an Android app using Capacitor.

## What is included
- `www/index.html` — standalone game: touch steering, auto machine gun, enemy fighters, asteroids, boss health bar, shields, lives, score and saved best score.
- `package.json` — Capacitor dependencies.
- `capacitor.config.ts` — Android app ID and display name.
- `PLAY_AND_BUILD.md` — setup, test and publishing checklist.

This is a starter project, not a signed APK or a Google Play-ready AAB. You must build and test it in Android Studio before publishing.

## Requirements
- A computer (Windows, macOS or Linux)
- Node.js 22 or newer
- Android Studio and Android SDK (API 36 for new Google Play submissions as of 31 Aug 2026)
- For Google Play: an adult account holder (18+) and Play Console registration.
